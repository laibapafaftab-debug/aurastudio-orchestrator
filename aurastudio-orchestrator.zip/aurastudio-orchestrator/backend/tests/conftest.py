"""Shared test setup. Environment is configured BEFORE the app is imported."""
import os
import tempfile

import bcrypt
import pytest

_tmp = tempfile.mkdtemp()
ADMIN_EMAIL = "admin@example.com"
ADMIN_PASSWORD = "correct-horse-battery"
os.environ.update(
    {
        "APP_ENV": "development",
        "SECRET_KEY": "x" * 48,
        "DATABASE_URL": f"sqlite:///{_tmp}/test.db",
        "ADMIN_EMAIL": ADMIN_EMAIL,
        "ADMIN_PASSWORD_HASH": bcrypt.hashpw(ADMIN_PASSWORD.encode(), bcrypt.gensalt(rounds=4)).decode(),
        "ANTHROPIC_API_KEY": "",
        "N8N_WEBHOOK_URL": "",
        "SITE_ORIGINS": "http://localhost:8080",
    }
)

from fastapi.testclient import TestClient  # noqa: E402

from app.api import auth as auth_api  # noqa: E402
from app.api import leads as leads_api  # noqa: E402
from app.main import app  # noqa: E402

CSRF = {"X-Requested-By": "aurastudio"}


@pytest.fixture(autouse=True)
def reset_limiters():
    auth_api.login_limiter.reset()
    leads_api.lead_limiter.reset()
    yield


@pytest.fixture
def client():
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def admin(client):
    response = client.post("/api/v1/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, headers=CSRF)
    assert response.status_code == 200
    return client
