from tests.conftest import ADMIN_EMAIL, ADMIN_PASSWORD, CSRF

VALID_LEAD = {
    "name": "Sample Lead",
    "email": "Sample@Example.com",
    "role": "Founder",
    "message": "I need help automating follow-up for my coaching leads.",
}


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_security_headers_present(client):
    headers = client.get("/health").headers
    assert headers["x-content-type-options"] == "nosniff"
    assert headers["x-frame-options"] == "DENY"


def test_lead_validation_rejects_bad_input(client):
    assert client.post("/api/v1/leads", json={"name": "", "email": "x", "message": "short"}).status_code == 422
    too_long = {**VALID_LEAD, "message": "a" * 2001}
    assert client.post("/api/v1/leads", json=too_long).status_code == 422


def test_public_lead_is_saved_scored_and_visible_to_admin(admin):
    assert admin.post("/api/v1/leads", json=VALID_LEAD).status_code == 202
    data = admin.get("/api/v1/leads", headers=CSRF).json()
    lead = data["items"][0]
    assert lead["email"] == "sample@example.com"
    assert lead["intent"] in ("high", "medium", "low")  # scored in the background task
    assert lead["scored_by"] == "rules"


def test_honeypot_stores_nothing(admin):
    before = admin.get("/api/v1/leads", headers=CSRF).json()["total"]
    admin.post("/api/v1/leads", json={**VALID_LEAD, "hp_field": "i am a bot"})
    assert admin.get("/api/v1/leads", headers=CSRF).json()["total"] == before


def test_lead_rate_limit(client):
    codes = [client.post("/api/v1/leads", json=VALID_LEAD).status_code for _ in range(6)]
    assert codes[:5] == [202] * 5
    assert codes[5] == 429


def test_admin_routes_require_login(client):
    assert client.get("/api/v1/leads", headers=CSRF).status_code == 401
    assert client.get("/api/v1/leads/stats", headers=CSRF).status_code == 401
    assert client.get("/api/v1/workflows", headers=CSRF).status_code == 401
    assert client.get("/api/v1/auth/me").status_code == 401


def test_login_rejects_wrong_password_and_sets_httponly_cookie_on_success(client):
    bad = client.post("/api/v1/auth/login", json={"email": ADMIN_EMAIL, "password": "wrong-password"}, headers=CSRF)
    assert bad.status_code == 401
    good = client.post("/api/v1/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, headers=CSRF)
    assert good.status_code == 200
    assert "httponly" in good.headers["set-cookie"].lower()


def test_login_is_rate_limited(client):
    codes = [
        client.post("/api/v1/auth/login", json={"email": ADMIN_EMAIL, "password": "nope-nope-nope"}, headers=CSRF).status_code
        for _ in range(11)
    ]
    assert codes[-1] == 429


def test_writes_without_csrf_header_are_rejected(admin):
    admin.post("/api/v1/leads", json=VALID_LEAD)
    lead_id = admin.get("/api/v1/leads", headers=CSRF).json()["items"][0]["id"]
    assert admin.patch(f"/api/v1/leads/{lead_id}", json={"status": "won"}).status_code == 403
    assert admin.patch(f"/api/v1/leads/{lead_id}", json={"status": "won"}, headers=CSRF).status_code == 200


def test_status_must_be_one_of_the_allowed_values(admin):
    admin.post("/api/v1/leads", json=VALID_LEAD)
    lead_id = admin.get("/api/v1/leads", headers=CSRF).json()["items"][0]["id"]
    assert admin.patch(f"/api/v1/leads/{lead_id}", json={"status": "hacked"}, headers=CSRF).status_code == 422


def test_stats_and_delete(admin):
    admin.post("/api/v1/leads", json=VALID_LEAD)
    stats = admin.get("/api/v1/leads/stats", headers=CSRF).json()
    assert stats["total"] >= 1
    lead_id = admin.get("/api/v1/leads", headers=CSRF).json()["items"][0]["id"]
    assert admin.delete(f"/api/v1/leads/{lead_id}", headers=CSRF).status_code == 204
    assert admin.delete(f"/api/v1/leads/{lead_id}", headers=CSRF).status_code == 404


def test_workflows_lists_runs_and_retrigger_needs_n8n(admin):
    admin.post("/api/v1/leads", json=VALID_LEAD)
    data = admin.get("/api/v1/workflows", headers=CSRF).json()
    assert data["n8n_configured"] is False
    assert data["runs"][0]["status"] == "skipped"
    assert admin.post("/api/v1/workflows/leads/1/retrigger", headers=CSRF).status_code == 409


def test_oversized_body_is_rejected(client):
    response = client.post("/api/v1/leads", content=b"x" * 30000, headers={"Content-Type": "application/json"})
    assert response.status_code == 413
