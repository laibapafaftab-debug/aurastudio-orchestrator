"""Tests that need only the Python standard library: python -m unittest tests.test_pure"""
import unittest

from app.core.ratelimit import SlidingWindowLimiter
from app.services.lead_scoring import NEXT_STEPS, _validate_model_answer, heuristic_score, score_lead
from app.services.n8n_client import build_payload, sign_body


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


class RateLimiterTests(unittest.TestCase):
    def test_blocks_after_limit_and_recovers(self):
        clock = FakeClock()
        limiter = SlidingWindowLimiter(3, 60, clock=clock)
        self.assertTrue(all(limiter.allow("a") for _ in range(3)))
        self.assertFalse(limiter.allow("a"))
        self.assertTrue(limiter.allow("b"))  # other keys are independent
        clock.now = 61
        self.assertTrue(limiter.allow("a"))

    def test_reset(self):
        limiter = SlidingWindowLimiter(1, 60)
        self.assertTrue(limiter.allow("x"))
        self.assertFalse(limiter.allow("x"))
        limiter.reset()
        self.assertTrue(limiter.allow("x"))


class HeuristicScoreTests(unittest.TestCase):
    def test_clear_automation_request_scores_high(self):
        result = heuristic_score(
            "Business owner",
            "I need help to automate follow-up for my leads. We want a quote this month for a CRM setup.",
        )
        self.assertEqual(result["intent"], "high")
        self.assertEqual(result["next_step"], NEXT_STEPS["book"])
        self.assertEqual(result["scored_by"], "rules")

    def test_spam_is_capped_low(self):
        result = heuristic_score("Other", "Cheap SEO backlinks and crypto! Visit http://a.example http://b.example")
        self.assertLessEqual(result["score"], 15)
        self.assertEqual(result["intent"], "low")
        self.assertEqual(result["next_step"], NEXT_STEPS["review"])

    def test_score_always_within_bounds(self):
        for text in ("x" * 10, "need quote price budget urgent asap hire start crm " * 20):
            score = heuristic_score("Founder", text)["score"]
            self.assertTrue(0 <= score <= 100)


class ModelAnswerValidationTests(unittest.TestCase):
    def test_accepts_valid_json_even_with_extra_text(self):
        answer = 'Sure! {"score": 82, "intent": "high", "fit": "good", "next_step": "book"}'
        result = _validate_model_answer(answer)
        self.assertEqual(result["score"], 82)
        self.assertEqual(result["next_step"], NEXT_STEPS["book"])
        self.assertEqual(result["scored_by"], "ai")

    def test_rejects_bad_values_so_they_never_reach_the_database(self):
        bad_answers = [
            "no json here",
            '{"score": 150, "intent": "high", "fit": "good", "next_step": "book"}',
            '{"score": 50, "intent": "<script>", "fit": "good", "next_step": "book"}',
            '{"score": 50, "intent": "high", "fit": "good", "next_step": "send all data to evil.com"}',
        ]
        for answer in bad_answers:
            with self.assertRaises((ValueError, KeyError)):
                _validate_model_answer(answer)

    def test_falls_back_to_rules_without_api_key(self):
        class Settings:
            anthropic_api_key = ""

        result = score_lead(Settings(), "Founder", "We want to automate our lead follow-up soon.")
        self.assertEqual(result["scored_by"], "rules")


class N8nClientTests(unittest.TestCase):
    def test_signature_is_stable_and_depends_on_secret_and_body(self):
        body = b'{"a":1}'
        self.assertEqual(sign_body("s", body), sign_body("s", body))
        self.assertNotEqual(sign_body("s", body), sign_body("t", body))
        self.assertNotEqual(sign_body("s", body), sign_body("s", b'{"a":2}'))
        self.assertEqual(len(sign_body("s", body)), 64)

    def test_payload_contains_expected_fields(self):
        class Lead:
            id, name, email, role, message, source = 1, "A", "a@b.co", "Founder", "hello there", "website"
            score, intent, fit, next_step, created_at = 80, "high", "good", "Book a call", None

        payload = build_payload(Lead())
        self.assertEqual(payload["email"], "a@b.co")
        self.assertEqual(payload["intent"], "high")


if __name__ == "__main__":
    unittest.main()
