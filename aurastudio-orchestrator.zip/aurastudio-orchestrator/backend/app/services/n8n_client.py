"""Sends new leads to an n8n webhook, signed so n8n can verify they came from this backend."""
import hashlib
import hmac
import json


def sign_body(secret: str, body: bytes) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def build_payload(lead) -> dict:
    return {
        "id": lead.id,
        "name": lead.name,
        "email": lead.email,
        "role": lead.role,
        "message": lead.message,
        "source": lead.source,
        "score": lead.score,
        "intent": lead.intent,
        "fit": lead.fit,
        "next_step": lead.next_step,
        "created_at": lead.created_at.isoformat() if lead.created_at else None,
    }


def deliver(settings, payload: dict) -> tuple[str, int | None, str | None]:
    """Returns (status, http_status, short_error). Never raises."""
    import httpx

    body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    headers = {"Content-Type": "application/json"}
    if settings.n8n_webhook_secret:
        headers["X-Aura-Signature"] = "sha256=" + sign_body(settings.n8n_webhook_secret, body)
        headers["X-Aura-Secret"] = settings.n8n_webhook_secret
    try:
        response = httpx.post(settings.n8n_webhook_url, content=body, headers=headers, timeout=10.0)
    except Exception as exc:
        return "failed", None, type(exc).__name__
    if 200 <= response.status_code < 300:
        return "sent", response.status_code, None
    return "failed", response.status_code, f"HTTP {response.status_code}"
