"""Background work after a lead is saved: score it, then hand it to n8n."""
import logging

from app.core.config import get_settings
from app.core.db import SessionLocal
from app.models.tables import Lead, WorkflowRun
from app.services.lead_scoring import score_lead
from app.services.n8n_client import build_payload, deliver

logger = logging.getLogger("aurastudio.pipeline")


def _deliver(db, lead: Lead) -> None:
    settings = get_settings()
    if not settings.n8n_webhook_url:
        db.add(WorkflowRun(lead_id=lead.id, status="skipped", error="n8n not configured"))
    else:
        status, http_status, error = deliver(settings, build_payload(lead))
        db.add(WorkflowRun(lead_id=lead.id, status=status, http_status=http_status, error=error))
    db.commit()


def process_lead(lead_id: int) -> None:
    db = SessionLocal()
    try:
        lead = db.get(Lead, lead_id)
        if lead is None:
            return
        result = score_lead(get_settings(), lead.role, lead.message)
        lead.score = result["score"]
        lead.intent = result["intent"]
        lead.fit = result["fit"]
        lead.next_step = result["next_step"]
        lead.scored_by = result["scored_by"]
        db.commit()
        _deliver(db, lead)
    except Exception:
        logger.exception("lead pipeline failed (lead_id=%s)", lead_id)
    finally:
        db.close()


def deliver_lead(lead_id: int) -> None:
    """Re-send an existing lead to n8n (used by the dashboard's retrigger button)."""
    db = SessionLocal()
    try:
        lead = db.get(Lead, lead_id)
        if lead is not None:
            _deliver(db, lead)
    except Exception:
        logger.exception("n8n delivery failed (lead_id=%s)", lead_id)
    finally:
        db.close()
