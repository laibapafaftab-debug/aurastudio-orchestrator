"""Application settings, read from environment variables (or a .env file)."""
from functools import lru_cache

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

INSECURE_DEFAULT_SECRET = "change-me-to-a-long-random-string"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env", "../.env"), env_file_encoding="utf-8", extra="ignore"
    )

    app_env: str = "development"
    secret_key: str = INSECURE_DEFAULT_SECRET
    database_url: str = "sqlite:///./data/aurastudio.db"

    # Single admin account for the dashboard
    admin_email: str = ""
    admin_password_hash: str = ""

    # Websites allowed to POST leads (comma separated, exact origins)
    site_origins: str = "http://localhost:8080,http://127.0.0.1:8080"

    cookie_secure: bool = False
    trust_proxy: bool = False
    session_hours: int = 8

    # AI scoring (optional: falls back to simple rules when no key is set)
    anthropic_api_key: str = ""
    scoring_model: str = "claude-haiku-5-5"

    # n8n hand-off (optional)
    n8n_webhook_url: str = ""
    n8n_webhook_secret: str = ""

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() == "production"

    @property
    def site_origins_list(self) -> list[str]:
        return [o.strip().rstrip("/") for o in self.site_origins.split(",") if o.strip()]

    @model_validator(mode="after")
    def refuse_weak_production_config(self):
        if self.is_production:
            if self.secret_key == INSECURE_DEFAULT_SECRET or len(self.secret_key) < 32:
                raise ValueError("SECRET_KEY must be a random string of at least 32 characters in production")
            if not self.cookie_secure:
                raise ValueError("COOKIE_SECURE must be true in production (serve the dashboard over HTTPS)")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
