"""Tiny in-memory sliding-window rate limiter (no third-party dependencies).

Limits are per process. If you run several backend workers, use a shared store such as Redis instead.
"""
import threading
import time
from collections import defaultdict, deque


class SlidingWindowLimiter:
    def __init__(self, max_events: int, window_seconds: float, clock=time.monotonic):
        self.max_events = max_events
        self.window = window_seconds
        self._clock = clock
        self._events: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = self._clock()
        cutoff = now - self.window
        with self._lock:
            queue = self._events[key]
            while queue and queue[0] <= cutoff:
                queue.popleft()
            if len(queue) >= self.max_events:
                return False
            queue.append(now)
            if len(self._events) > 10_000:  # keep memory bounded
                for stale in [k for k, q in self._events.items() if not q]:
                    del self._events[stale]
            return True

    def reset(self) -> None:
        with self._lock:
            self._events.clear()
