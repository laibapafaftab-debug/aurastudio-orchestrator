"""Password checking, session tokens and request helpers."""
import hashlib
import hmac
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from fastapi import Request

from app.core.config import get_settings

COOKIE_NAME = "aura_session"
_DUMMY_HASH = bcrypt.hashpw(b"dummy-password", bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except (ValueError, TypeError):
        return False


def authenticate(email: str, password: str) -> bool:
    """Always does the same amount of work, so timing does not reveal whether the email exists."""
    s = get_settings()
    password_ok = verify_password(password, s.admin_password_hash or _DUMMY_HASH)
    email_ok = hmac.compare_digest(
        email.strip().lower().encode(), s.admin_email.strip().lower().encode()
    )
    return bool(s.admin_email and s.admin_password_hash and password_ok and email_ok)


def create_session(email: str) -> str:
    s = get_settings()
    now = datetime.now(timezone.utc)
    payload = {"sub": email.strip().lower(), "iat": now, "exp": now + timedelta(hours=s.session_hours)}
    return jwt.encode(payload, s.secret_key, algorithm="HS256")


def decode_session(token: str) -> str | None:
    try:
        data = jwt.decode(
            token, get_settings().secret_key, algorithms=["HS256"], options={"require": ["exp", "sub"]}
        )
        return str(data["sub"])
    except jwt.PyJWTError:
        return None


def get_client_ip(request: Request, trust_proxy: bool) -> str:
    """Only trust X-Forwarded-For when the backend sits behind your own reverse proxy."""
    if trust_proxy:
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def hash_ip(ip: str, secret: str) -> str:
    """Stores a keyed hash instead of the raw IP address."""
    return hmac.new(secret.encode(), ip.encode(), hashlib.sha256).hexdigest()
