"""AuraStudio Orchestrator: lead capture API for your website + dashboard backend."""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import auth, leads, workflows
from app.core.config import get_settings
from app.core.db import Base, engine
from app.models import tables  # noqa: F401  (registers the tables)

settings = get_settings()
Base.metadata.create_all(bind=engine)  # fine for a starter; use Alembic migrations once the schema grows

MAX_BODY_BYTES = 20_000

app = FastAPI(
    title="AuraStudio Orchestrator",
    version="0.1.0",
    docs_url=None if settings.is_production else "/docs",
    redoc_url=None,
    openapi_url=None if settings.is_production else "/openapi.json",
)


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > MAX_BODY_BYTES:
        return JSONResponse({"detail": "Request too large"}, status_code=413)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if settings.is_production:
        response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    return response


# Added last so it is the outermost layer: only your own websites may call the public lead endpoint.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.site_origins_list,
    allow_credentials=False,
    allow_methods=["POST", "OPTIONS"],
    allow_headers=["Content-Type"],
    max_age=600,
)

app.include_router(auth.router, prefix="/api/v1")
app.include_router(leads.public_router, prefix="/api/v1")
app.include_router(leads.admin_router, prefix="/api/v1")
app.include_router(workflows.router, prefix="/api/v1")


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
