"""Shared request dependencies: database session, admin check and CSRF check."""
import hmac

from fastapi import HTTPException, Request

from app.core.config import get_settings
from app.core.db import SessionLocal
from app.core.security import COOKIE_NAME, decode_session


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def require_admin(request: Request) -> str:
    token = request.cookies.get(COOKIE_NAME)
    email = decode_session(token) if token else None
    admin = get_settings().admin_email.strip().lower()
    if not email or not admin or not hmac.compare_digest(email.encode(), admin.encode()):
        raise HTTPException(status_code=401, detail="Not authenticated")
    return email


def require_csrf(request: Request) -> None:
    """Writes must carry a custom header. Browsers cannot add it cross-site without a CORS preflight,
    and the CORS policy only allows your own websites, so forged requests from other sites fail."""
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        if request.headers.get("x-requested-by") != "aurastudio":
            raise HTTPException(status_code=403, detail="Missing request header")
