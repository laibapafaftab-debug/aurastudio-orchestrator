from fastapi import APIRouter, Depends, HTTPException, Request, Response

from app.api.deps import require_admin, require_csrf
from app.core.config import get_settings
from app.core.ratelimit import SlidingWindowLimiter
from app.core.security import COOKIE_NAME, authenticate, create_session, get_client_ip
from app.models.schemas import LoginIn, MeOut

router = APIRouter(prefix="/auth", tags=["auth"])
login_limiter = SlidingWindowLimiter(max_events=10, window_seconds=900)  # 10 attempts / 15 min / IP


def limit_login(request: Request) -> None:
    ip = get_client_ip(request, get_settings().trust_proxy)
    if not login_limiter.allow(ip):
        raise HTTPException(status_code=429, detail="Too many attempts. Try again later.")


@router.post("/login", dependencies=[Depends(limit_login), Depends(require_csrf)])
def login(payload: LoginIn, response: Response) -> MeOut:
    if not authenticate(payload.email, payload.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    settings = get_settings()
    response.set_cookie(
        COOKIE_NAME,
        create_session(payload.email),
        max_age=settings.session_hours * 3600,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        path="/",
    )
    return MeOut(email=payload.email.strip().lower())


@router.post("/logout", dependencies=[Depends(require_csrf)])
def logout(response: Response) -> dict:
    response.delete_cookie(COOKIE_NAME, path="/")
    return {"ok": True}


@router.get("/me")
def me(email: str = Depends(require_admin)) -> MeOut:
    return MeOut(email=email)
