from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_admin, require_csrf
from app.core.config import get_settings
from app.models.schemas import WorkflowRunOut, WorkflowsOut
from app.models.tables import Lead, WorkflowRun
from app.services.pipeline import deliver_lead

router = APIRouter(
    prefix="/workflows", tags=["workflows"], dependencies=[Depends(require_admin), Depends(require_csrf)]
)


@router.get("")
def list_runs(db: Session = Depends(get_db)) -> WorkflowsOut:
    rows = db.execute(
        select(WorkflowRun, Lead.name)
        .join(Lead, Lead.id == WorkflowRun.lead_id, isouter=True)
        .order_by(WorkflowRun.id.desc())
        .limit(50)
    ).all()
    runs = [
        WorkflowRunOut(
            id=run.id,
            lead_id=run.lead_id,
            lead_name=name,
            status=run.status,
            http_status=run.http_status,
            error=run.error,
            created_at=run.created_at,
        )
        for run, name in rows
    ]
    return WorkflowsOut(n8n_configured=bool(get_settings().n8n_webhook_url), runs=runs)


@router.post("/leads/{lead_id}/retrigger", status_code=202)
def retrigger(lead_id: int, background: BackgroundTasks, db: Session = Depends(get_db)) -> dict:
    if not get_settings().n8n_webhook_url:
        raise HTTPException(status_code=409, detail="n8n is not configured")
    if db.get(Lead, lead_id) is None:
        raise HTTPException(status_code=404, detail="Lead not found")
    background.add_task(deliver_lead, lead_id)
    return {"ok": True}
