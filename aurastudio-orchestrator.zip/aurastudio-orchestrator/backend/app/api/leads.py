from datetime import timedelta
from typing import Literal

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_admin, require_csrf
from app.core.config import get_settings
from app.core.ratelimit import SlidingWindowLimiter
from app.core.security import get_client_ip, hash_ip
from app.models.schemas import LeadIn, LeadList, LeadOut, LeadPatch, Stats
from app.models.tables import Lead, WorkflowRun, utcnow
from app.services.pipeline import process_lead

# ---- Public: your website's contact form posts here -------------------------------------------
public_router = APIRouter(prefix="/leads", tags=["leads"])
lead_limiter = SlidingWindowLimiter(max_events=5, window_seconds=600)  # 5 enquiries / 10 min / IP


def limit_leads(request: Request) -> None:
    ip = get_client_ip(request, get_settings().trust_proxy)
    if not lead_limiter.allow(ip):
        raise HTTPException(status_code=429, detail="Too many requests. Please try again later.")


@public_router.post("", status_code=202, dependencies=[Depends(limit_leads)])
def create_lead(
    payload: LeadIn, request: Request, background: BackgroundTasks, db: Session = Depends(get_db)
) -> dict:
    if payload.hp_field:  # a bot filled the hidden field: pretend it worked, store nothing
        return {"ok": True}
    settings = get_settings()
    ip = get_client_ip(request, settings.trust_proxy)
    lead = Lead(
        name=payload.name,
        email=payload.email,
        role=payload.role,
        message=payload.message,
        source=payload.source or "website",
        ip_hash=hash_ip(ip, settings.secret_key),
    )
    db.add(lead)
    db.commit()
    db.refresh(lead)
    background.add_task(process_lead, lead.id)
    return {"ok": True}


# ---- Admin: dashboard only ---------------------------------------------------------------------
admin_router = APIRouter(
    prefix="/leads", tags=["leads"], dependencies=[Depends(require_admin), Depends(require_csrf)]
)


@admin_router.get("/stats")
def stats(db: Session = Depends(get_db)) -> Stats:
    total = db.scalar(select(func.count(Lead.id))) or 0
    rows = db.execute(select(Lead.status, func.count(Lead.id)).group_by(Lead.status)).all()
    by_status = {status: count for status, count in rows}
    high = db.scalar(select(func.count(Lead.id)).where(Lead.intent == "high")) or 0
    week_ago = utcnow() - timedelta(days=7)
    recent = db.scalar(select(func.count(Lead.id)).where(Lead.created_at >= week_ago)) or 0
    return Stats(
        total=total,
        new=by_status.get("new", 0),
        high_intent=high,
        last_7_days=recent,
        by_status=by_status,
    )


@admin_router.get("")
def list_leads(
    status: Literal["new", "contacted", "won", "lost"] | None = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
) -> LeadList:
    query = select(Lead)
    count_query = select(func.count(Lead.id))
    if status:
        query = query.where(Lead.status == status)
        count_query = count_query.where(Lead.status == status)
    items = db.scalars(query.order_by(Lead.id.desc()).limit(limit).offset(offset)).all()
    total = db.scalar(count_query) or 0
    return LeadList(items=[LeadOut.model_validate(i) for i in items], total=total)


@admin_router.patch("/{lead_id}")
def update_lead(lead_id: int, patch: LeadPatch, db: Session = Depends(get_db)) -> LeadOut:
    lead = db.get(Lead, lead_id)
    if lead is None:
        raise HTTPException(status_code=404, detail="Lead not found")
    lead.status = patch.status
    db.commit()
    return LeadOut.model_validate(lead)


@admin_router.delete("/{lead_id}", status_code=204)
def delete_lead(lead_id: int, db: Session = Depends(get_db)) -> Response:
    lead = db.get(Lead, lead_id)
    if lead is None:
        raise HTTPException(status_code=404, detail="Lead not found")
    for run in db.scalars(select(WorkflowRun).where(WorkflowRun.lead_id == lead_id)).all():
        db.delete(run)
    db.delete(lead)
    db.commit()
    return Response(status_code=204)
