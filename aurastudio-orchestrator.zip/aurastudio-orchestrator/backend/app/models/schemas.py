"""Request and response shapes. Every input is length-limited and stripped of control characters."""
import re
from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_EMAIL = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")

Status = Literal["new", "contacted", "won", "lost"]


def _clean(value):
    if not isinstance(value, str):
        raise ValueError("must be text")
    return _CONTROL_CHARS.sub("", value).strip()


class LeadIn(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str = Field(min_length=1, max_length=80)
    email: str = Field(min_length=3, max_length=120)
    role: str = Field(default="", max_length=40)
    message: str = Field(min_length=10, max_length=2000)
    source: str = Field(default="website", max_length=40)
    hp_field: str = Field(default="", max_length=200)  # honeypot: real visitors never fill this

    @field_validator("name", "email", "role", "message", "source", "hp_field", mode="before")
    @classmethod
    def clean_text(cls, value):
        return _clean(value)

    @field_validator("email")
    @classmethod
    def valid_email(cls, value: str) -> str:
        if not _EMAIL.match(value):
            raise ValueError("invalid email address")
        return value.lower()


class LeadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    email: str
    role: str
    message: str
    source: str
    status: str
    score: int | None
    intent: str | None
    fit: str | None
    next_step: str | None
    scored_by: str | None
    created_at: datetime

    @field_validator("created_at")
    @classmethod
    def assume_utc(cls, value: datetime) -> datetime:
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


class LeadList(BaseModel):
    items: list[LeadOut]
    total: int


class LeadPatch(BaseModel):
    status: Status


class Stats(BaseModel):
    total: int
    new: int
    high_intent: int
    last_7_days: int
    by_status: dict[str, int]


class LoginIn(BaseModel):
    email: str = Field(min_length=3, max_length=120)
    password: str = Field(min_length=1, max_length=200)

    @field_validator("password")
    @classmethod
    def bcrypt_limit(cls, value: str) -> str:
        if len(value.encode()) > 72:
            raise ValueError("password too long")
        return value


class MeOut(BaseModel):
    email: str


class WorkflowRunOut(BaseModel):
    id: int
    lead_id: int
    lead_name: str | None
    status: str
    http_status: int | None
    error: str | None
    created_at: datetime


class WorkflowsOut(BaseModel):
    n8n_configured: bool
    runs: list[WorkflowRunOut]
