"""Creates the bcrypt hash for ADMIN_PASSWORD_HASH. Run: python scripts/hash_password.py"""
import getpass
import sys

import bcrypt


def main() -> None:
    password = getpass.getpass("Admin password (at least 12 characters): ")
    if len(password) < 12:
        sys.exit("Please use at least 12 characters.")
    if len(password.encode()) > 72:
        sys.exit("bcrypt supports passwords up to 72 bytes.")
    if password != getpass.getpass("Repeat password: "):
        sys.exit("Passwords do not match.")
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12)).decode()
    print("\nAdd this line to your .env file (keep the single quotes):\n")
    print(f"ADMIN_PASSWORD_HASH='{hashed}'")


if __name__ == "__main__":
    main()
