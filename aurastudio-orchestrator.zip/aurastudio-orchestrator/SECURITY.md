# Security Policy

## Reporting a vulnerability

Please email **laibapafaftab@gmail.com** with a short description and steps to reproduce. Do not open a public issue or post details until it has been fixed.

## Scope

The backend API, the dashboard, and the deployment files in this repository. Please do not test against other people's data or run denial-of-service tests.

## For contributors

- Never commit `.env`, keys, tokens or real lead data.
- Treat everything a visitor submits as untrusted input.
- Dependencies are kept current with Dependabot. Review and merge its pull requests.
