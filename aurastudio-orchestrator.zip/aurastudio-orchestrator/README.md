# AuraStudio Orchestrator

A small self-hosted system that sits behind your website's contact form:

```
Website form ──► Backend (FastAPI) ──► Database (SQLite or Supabase/Postgres)
                      │                        ▲
                      ├─ scores the lead (Claude, or simple rules)      Dashboard (Next.js)
                      └─ sends it to n8n (signed webhook) ──► your follow-up workflow
```

- **backend/**: FastAPI API. Public `POST /api/v1/leads` for your website, login-protected routes for the dashboard.
- **frontend/**: Next.js 14 dashboard (Dashboard, Leads, Workflows, Settings).
- **docker-compose.yml**: runs backend, dashboard and n8n together.

> Status: first version. After installing, run the backend tests (`pytest`) and `npm run build`, and fix anything your environment shows before deploying.

## Quick start with Docker

1. Copy the example settings and fill them in:
   ```bash
   cp .env.example .env
   ```
2. Generate secrets and put them in `.env`:
   ```bash
   python -c "import secrets; print(secrets.token_urlsafe(48))"   # SECRET_KEY and N8N_ENCRYPTION_KEY (run twice)
   python backend/scripts/hash_password.py                        # ADMIN_PASSWORD_HASH (needs: pip install bcrypt)
   ```
   Set `ADMIN_EMAIL` too. Keep the single quotes around the hash.
3. Start everything:
   ```bash
   docker compose up --build
   ```
4. Open the dashboard at http://localhost:3000, n8n at http://localhost:5678. The API health check is http://localhost:8000/health.

All ports are bound to `127.0.0.1`, so nothing is public until you add an HTTPS reverse proxy.

## Run without Docker (development)

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp ../.env.example ../.env        # then set DATABASE_URL=sqlite:///./data/aurastudio.db
uvicorn app.main:app --reload

# dashboard (new terminal)
cd frontend
npm install
npm run dev                        # http://localhost:3000 (proxies /api to http://localhost:8000)
```

## Connect your website

In the website's `script.js`, set the form address:

```js
var WEBHOOK_URL = 'https://api.yourdomain.com/api/v1/leads';
```

Then:

1. Add the website's address to `SITE_ORIGINS` in `.env` (exact origin, for example `https://aurastudio.pro`).
2. Add the API address to the site's Content Security Policy: `connect-src https://api.yourdomain.com`.

The form already sends the fields the API expects (`name`, `email`, `role`, `message`).

## Connect n8n

1. In n8n create a workflow that starts with a **Webhook** node: method `POST`, path `aurastudio-lead`.
2. Set its authentication to **Header Auth** with header name `X-Aura-Secret` and the same value as `N8N_WEBHOOK_SECRET`.
3. Add your follow-up steps. The lead arrives under `body`, for example `{{ $json.body.email }}`, `{{ $json.body.intent }}`, `{{ $json.body.next_step }}`. A good first workflow: if `intent` is `high`, send yourself an alert and the lead a booking link.
4. **Activate** the workflow, then set in `.env`:
   ```
   N8N_WEBHOOK_URL=http://n8n:5678/webhook/aurastudio-lead
   N8N_WEBHOOK_SECRET=<the same secret>
   ```
   (`/webhook-test/...` only works while you are listening in the editor; use `/webhook/...` for real traffic.)
5. Restart the backend. The Workflows page shows every hand-off and lets you send a lead again.

Requests also carry `X-Aura-Signature: sha256=<hmac>` (HMAC-SHA256 of the raw body with your secret) if you want to verify them in a Code node.

## Use Supabase (Postgres)

Supabase is Postgres, so set `DATABASE_URL` in `.env`:

```
DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/postgres?sslmode=require
```

Tables are created on start. When the schema starts to change, add Alembic migrations.

## AI scoring

Set `ANTHROPIC_API_KEY` to score leads with Claude (`SCORING_MODEL` defaults to a small, fast model). Without a key, or if the call fails, simple keyword rules are used, so leads are never lost. Lead text is treated as untrusted: the model is told to ignore instructions inside it and its answer is checked against fixed options before anything is stored.

## Security model

- **Admin login:** bcrypt password hash, signed session in an `HttpOnly`, `SameSite=Lax` cookie (`Secure` when `COOKIE_SECURE=true`), 10 login attempts per 15 minutes per IP, same work whether or not the email exists.
- **CSRF:** every write needs the `X-Requested-By` header, which other websites cannot send; CORS only allows your own site origins.
- **Public endpoint:** strict length limits, control-character stripping, honeypot field, 5 enquiries per 10 minutes per IP, 20 KB body limit.
- **Privacy:** only a keyed hash of the visitor's IP is stored, not the address.
- **Headers:** `nosniff`, `X-Frame-Options: DENY`, `no-store`, HSTS in production. API docs are switched off in production.
- **Startup guard:** `APP_ENV=production` refuses to start with a weak `SECRET_KEY` or without `COOKIE_SECURE=true`.
- **Secrets** live only in `.env` (git-ignored). The n8n hand-off is signed.

Known limits (be aware, fix when you outgrow them):

- Rate limits are in memory and per process. With several workers or servers, use Redis.
- Sessions are stateless: logging out removes the cookie but a stolen cookie stays valid until it expires (8 hours by default).
- One admin account only.
- `TRUST_PROXY=false` means the backend sees the dashboard container as the client, so all dashboard logins share one rate-limit bucket. Behind a reverse proxy **that overwrites `X-Forwarded-For`**, set `TRUST_PROXY=true`. Never set it when the backend is directly reachable from the internet.
- Keep `npm audit` and dependency updates on your routine; keep Next.js on the latest 14.2.x patch.

## Production checklist

- [ ] HTTPS reverse proxy in front (Caddy, Nginx, Cloudflare Tunnel) for the dashboard, the API and n8n
- [ ] `APP_ENV=production`, `COOKIE_SECURE=true`, strong `SECRET_KEY`, long admin password
- [ ] n8n owner account created with a strong password, `N8N_SECURE_COOKIE=true` behind HTTPS, version pinned in `docker-compose.yml`
- [ ] Do not expose the n8n editor or the database to the internet
- [ ] Two-factor authentication on GitHub, your server provider and Supabase
- [ ] Back up the `aura_data` volume (or use Supabase backups) and `n8n_data`
- [ ] Mention in your privacy notice that enquiries are stored and processed (and sent to an AI provider if scoring is on)

## Tests

```bash
cd backend
pytest -q                       # full API tests
python -m unittest tests.test_pure   # no-dependency tests (scoring, rate limiter, signing)
```

## Repository structure

```
aurastudio-orchestrator/
├── .github/
│   ├── workflows/ci.yml            tests + build on every push and pull request
│   ├── dependabot.yml              automatic dependency and security update PRs
│   ├── CODEOWNERS
│   └── pull_request_template.md
├── backend/                        FastAPI
│   ├── app/
│   │   ├── api/                    routes: auth, leads, workflows (+ shared deps)
│   │   ├── core/                   config, database, security, rate limiting
│   │   ├── services/               lead scoring, n8n client, background pipeline
│   │   ├── models/                 tables.py (database) and schemas.py (requests/responses)
│   │   └── main.py
│   ├── scripts/hash_password.py
│   ├── tests/
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/                       Next.js 14 dashboard
│   ├── src/
│   │   ├── app/                    login + (app)/ dashboard, leads, workflows, settings
│   │   ├── components/             reusable UI
│   │   ├── lib/                    API helper, formatting
│   │   └── types/
│   └── Dockerfile
├── infra/caddy/Caddyfile           HTTPS reverse proxy config (production)
├── n8n/workflows/                  exported n8n workflows (versioned)
├── docs/                           architecture.md, deployment.md
├── docker-compose.yml              local development stack
├── docker-compose.prod.yml         production stack (Caddy + HTTPS, only 80/443 public)
├── .env.example
├── CONTRIBUTING.md
├── SECURITY.md
└── README.md
```

More detail: [docs/architecture.md](docs/architecture.md) and [docs/deployment.md](docs/deployment.md).
