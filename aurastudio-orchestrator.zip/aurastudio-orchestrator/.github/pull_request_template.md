## What changed

## Why

## Checklist
- [ ] Tests added or updated, and `pytest` passes
- [ ] `npm run build` passes (if the dashboard changed)
- [ ] No secrets, passwords or personal data in the diff
- [ ] README or docs updated if behaviour changed
