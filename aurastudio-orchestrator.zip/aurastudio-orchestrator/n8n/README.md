# n8n workflows

Export your workflows from n8n (menu, **Download**) and save the JSON files in `workflows/` so they are versioned with the code.

Before committing an export, check it contains no credentials or secrets (n8n exports credential names, not values, but always look).

The backend sends each new lead to the webhook set in `N8N_WEBHOOK_URL`. See the README section "Connect n8n" for the webhook setup.
