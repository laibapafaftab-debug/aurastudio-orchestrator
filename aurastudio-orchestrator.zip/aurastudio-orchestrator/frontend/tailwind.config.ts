import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        aura: {
          bg: "#0C110F",
          surface: "#161E1A",
          line: "#26312B",
          ink: "#EEF1EA",
          muted: "#9AA69E",
          lime: "#C8F169",
        },
      },
    },
  },
  plugins: [],
};

export default config;
