import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Convenience only: sends visitors without a session cookie to the login page.
// Real protection happens in the backend, which checks the signed session on every API call.
export function middleware(req: NextRequest) {
  if (!req.cookies.has("aura_session")) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/leads/:path*", "/workflows/:path*", "/settings/:path*"],
};
