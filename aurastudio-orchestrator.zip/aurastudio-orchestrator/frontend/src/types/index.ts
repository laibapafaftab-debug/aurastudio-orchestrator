export type LeadStatus = "new" | "contacted" | "won" | "lost";

export interface Lead {
  id: number;
  name: string;
  email: string;
  role: string;
  message: string;
  source: string;
  status: LeadStatus;
  score: number | null;
  intent: "high" | "medium" | "low" | null;
  fit: "good" | "ok" | "poor" | null;
  next_step: string | null;
  scored_by: "ai" | "rules" | null;
  created_at: string;
}

export interface LeadList {
  items: Lead[];
  total: number;
}

export interface Stats {
  total: number;
  new: number;
  high_intent: number;
  last_7_days: number;
  by_status: Record<string, number>;
}

export interface WorkflowRun {
  id: number;
  lead_id: number;
  lead_name: string | null;
  status: "sent" | "failed" | "skipped";
  http_status: number | null;
  error: string | null;
  created_at: string;
}

export interface Workflows {
  n8n_configured: boolean;
  runs: WorkflowRun[];
}

export interface Me {
  email: string;
}
