import type { Metadata } from "next";

import "./globals.css";

export const metadata: Metadata = {
  title: "AuraStudio Orchestrator",
  description: "Lead dashboard",
  robots: { index: false, follow: false },
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-aura-bg text-aura-ink antialiased">{children}</body>
    </html>
  );
}
