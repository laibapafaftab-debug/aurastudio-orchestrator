"use client";

import { useEffect, useState } from "react";

import { IntentBadge } from "@/components/Badge";
import { api } from "@/lib/api";
import { formatDate } from "@/lib/format";
import type { LeadList, LeadStatus } from "@/types";

const STATUSES: LeadStatus[] = ["new", "contacted", "won", "lost"];

export default function LeadsPage() {
  const [filter, setFilter] = useState("");
  const [data, setData] = useState<LeadList | null>(null);
  const [error, setError] = useState("");
  const [reload, setReload] = useState(0);

  useEffect(() => {
    const query = filter ? `?status=${encodeURIComponent(filter)}&limit=100` : "?limit=100";
    api
      .get<LeadList>(`/leads${query}`)
      .then((result) => {
        setData(result);
        setError("");
      })
      .catch((e: Error) => setError(e.message));
  }, [filter, reload]);

  async function changeStatus(id: number, status: LeadStatus) {
    try {
      await api.patch(`/leads/${id}`, { status });
      setReload((n) => n + 1);
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function remove(id: number, name: string) {
    if (!window.confirm(`Delete the lead from ${name}? This cannot be undone.`)) {
      return;
    }
    try {
      await api.del(`/leads/${id}`);
      setReload((n) => n + 1);
    } catch (e) {
      setError((e as Error).message);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Leads</h1>
          <p className="mt-1 text-sm text-aura-muted">{data ? `${data.total} total` : "Loading..."}</p>
        </div>
        <div>
          <label htmlFor="filter" className="mr-2 text-sm text-aura-muted">
            Status
          </label>
          <select
            id="filter"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="rounded-lg border border-aura-line bg-aura-surface px-3 py-2 text-sm"
          >
            <option value="">All</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
      </div>

      {error ? <p role="alert" className="mt-4 text-red-400">{error}</p> : null}

      <div className="mt-6 overflow-x-auto rounded-2xl border border-aura-line bg-aura-surface">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="border-b border-aura-line text-aura-muted">
            <tr>
              <th className="p-4 font-medium">Lead</th>
              <th className="p-4 font-medium">Message</th>
              <th className="p-4 font-medium">Intent</th>
              <th className="p-4 font-medium">Next step</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium">Received</th>
              <th className="p-4" />
            </tr>
          </thead>
          <tbody className="divide-y divide-aura-line">
            {(data?.items ?? []).map((lead) => (
              <tr key={lead.id} className="align-top">
                <td className="p-4">
                  <p className="font-medium">{lead.name}</p>
                  <p className="text-aura-muted">{lead.email}</p>
                  {lead.role ? <p className="text-xs text-aura-muted">{lead.role}</p> : null}
                </td>
                <td className="max-w-xs p-4 text-aura-muted">
                  <p className="line-clamp-3" title={lead.message}>
                    {lead.message}
                  </p>
                </td>
                <td className="p-4">
                  <IntentBadge intent={lead.intent} score={lead.score} />
                </td>
                <td className="p-4 text-aura-muted">{lead.next_step ?? "-"}</td>
                <td className="p-4">
                  <label className="sr-only" htmlFor={`status-${lead.id}`}>
                    Status for {lead.name}
                  </label>
                  <select
                    id={`status-${lead.id}`}
                    value={lead.status}
                    onChange={(e) => changeStatus(lead.id, e.target.value as LeadStatus)}
                    className="rounded-lg border border-aura-line bg-aura-bg px-2 py-1"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="whitespace-nowrap p-4 text-aura-muted">{formatDate(lead.created_at)}</td>
                <td className="p-4">
                  <button
                    type="button"
                    onClick={() => remove(lead.id, lead.name)}
                    className="text-red-400 hover:underline"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {data && data.items.length === 0 ? <p className="p-6 text-sm text-aura-muted">Nothing here yet.</p> : null}
      </div>
    </div>
  );
}
