"use client";

import { useEffect, useState } from "react";

import { api } from "@/lib/api";
import type { Me } from "@/types";

export default function SettingsPage() {
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get<Me>("/auth/me")
      .then(setMe)
      .catch((e: Error) => setError(e.message));
  }, []);

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold">Settings</h1>

      {error ? <p role="alert" className="mt-4 text-red-400">{error}</p> : null}

      <section className="mt-6 rounded-2xl border border-aura-line bg-aura-surface p-6">
        <h2 className="font-semibold">Account</h2>
        <p className="mt-2 text-sm text-aura-muted">Signed in as {me ? me.email : "..."}</p>
        <p className="mt-4 text-sm text-aura-muted">
          Sessions last 8 hours by default. To change the admin email or password, edit <code>ADMIN_EMAIL</code> and{" "}
          <code>ADMIN_PASSWORD_HASH</code> in your .env file and restart the backend.
        </p>
      </section>

      <section className="mt-6 rounded-2xl border border-aura-line bg-aura-surface p-6">
        <h2 className="font-semibold">Connecting your website</h2>
        <p className="mt-2 text-sm text-aura-muted">
          Point your website form at <code>/api/v1/leads</code> on your backend address, and add your website to{" "}
          <code>SITE_ORIGINS</code>. The README has the full steps.
        </p>
      </section>
    </div>
  );
}
