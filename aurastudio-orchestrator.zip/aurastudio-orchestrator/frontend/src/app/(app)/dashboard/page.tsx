"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

import { IntentBadge } from "@/components/Badge";
import StatCard from "@/components/StatCard";
import { api } from "@/lib/api";
import { formatDate } from "@/lib/format";
import type { LeadList, Stats } from "@/types";

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<LeadList | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.get<Stats>("/leads/stats"), api.get<LeadList>("/leads?limit=5")])
      .then(([s, r]) => {
        setStats(s);
        setRecent(r);
      })
      .catch((e: Error) => setError(e.message));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <p className="mt-1 text-sm text-aura-muted">How your lead pipeline is doing.</p>

      {error ? <p role="alert" className="mt-6 text-red-400">{error}</p> : null}

      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total leads" value={stats ? stats.total : "-"} />
        <StatCard label="New" value={stats ? stats.new : "-"} hint="Not contacted yet" />
        <StatCard label="High intent" value={stats ? stats.high_intent : "-"} hint="Scored by AI or rules" />
        <StatCard label="Last 7 days" value={stats ? stats.last_7_days : "-"} />
      </div>

      <section className="mt-10">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Latest enquiries</h2>
          <Link href="/leads" className="text-sm text-aura-lime hover:underline">
            View all
          </Link>
        </div>
        <div className="mt-4 overflow-hidden rounded-2xl border border-aura-line bg-aura-surface">
          {recent && recent.items.length === 0 ? (
            <p className="p-6 text-sm text-aura-muted">No leads yet. They appear here when someone uses your website form.</p>
          ) : null}
          <ul className="divide-y divide-aura-line">
            {(recent?.items ?? []).map((lead) => (
              <li key={lead.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <p className="truncate font-medium">{lead.name}</p>
                  <p className="truncate text-sm text-aura-muted">{lead.email}</p>
                </div>
                <div className="flex items-center gap-4">
                  <IntentBadge intent={lead.intent} score={lead.score} />
                  <span className="text-xs text-aura-muted">{formatDate(lead.created_at)}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
