"use client";

import { useEffect, useState } from "react";

import { RunBadge } from "@/components/Badge";
import { api } from "@/lib/api";
import { formatDate } from "@/lib/format";
import type { Workflows } from "@/types";

export default function WorkflowsPage() {
  const [data, setData] = useState<Workflows | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reload, setReload] = useState(0);

  useEffect(() => {
    api
      .get<Workflows>("/workflows")
      .then((result) => {
        setData(result);
        setError("");
      })
      .catch((e: Error) => setError(e.message));
  }, [reload]);

  async function retrigger(leadId: number) {
    setNotice("");
    try {
      await api.post(`/workflows/leads/${leadId}/retrigger`);
      setNotice("Sent again. Refresh in a moment to see the result.");
      setTimeout(() => setReload((n) => n + 1), 1500);
    } catch (e) {
      setError((e as Error).message);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">Workflows</h1>
      <p className="mt-1 text-sm text-aura-muted">Every time a lead is handed to n8n, it is logged here.</p>

      {data && !data.n8n_configured ? (
        <p className="mt-6 rounded-xl border border-aura-line bg-aura-surface p-4 text-sm text-aura-muted">
          n8n is not connected yet. Set <code>N8N_WEBHOOK_URL</code> and <code>N8N_WEBHOOK_SECRET</code> in your .env file,
          then restart the backend.
        </p>
      ) : null}

      {error ? <p role="alert" className="mt-4 text-red-400">{error}</p> : null}
      {notice ? <p role="status" className="mt-4 text-aura-lime">{notice}</p> : null}

      <div className="mt-6 overflow-x-auto rounded-2xl border border-aura-line bg-aura-surface">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="border-b border-aura-line text-aura-muted">
            <tr>
              <th className="p-4 font-medium">Lead</th>
              <th className="p-4 font-medium">Result</th>
              <th className="p-4 font-medium">Detail</th>
              <th className="p-4 font-medium">When</th>
              <th className="p-4" />
            </tr>
          </thead>
          <tbody className="divide-y divide-aura-line">
            {(data?.runs ?? []).map((run) => (
              <tr key={run.id}>
                <td className="p-4">{run.lead_name ?? `Lead #${run.lead_id}`}</td>
                <td className="p-4">
                  <RunBadge status={run.status} />
                </td>
                <td className="p-4 text-aura-muted">{run.error ?? (run.http_status ? `HTTP ${run.http_status}` : "-")}</td>
                <td className="whitespace-nowrap p-4 text-aura-muted">{formatDate(run.created_at)}</td>
                <td className="p-4">
                  {data?.n8n_configured ? (
                    <button type="button" onClick={() => retrigger(run.lead_id)} className="text-aura-lime hover:underline">
                      Send again
                    </button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {data && data.runs.length === 0 ? <p className="p-6 text-sm text-aura-muted">No runs yet.</p> : null}
      </div>
    </div>
  );
}
