"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

import { api } from "@/lib/api";

const links = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/leads", label: "Leads" },
  { href: "/workflows", label: "Workflows" },
  { href: "/settings", label: "Settings" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  async function signOut() {
    try {
      await api.post("/auth/logout");
    } finally {
      router.push("/login");
    }
  }

  return (
    <aside className="border-b border-aura-line bg-aura-surface md:min-h-screen md:w-60 md:border-b-0 md:border-r">
      <div className="flex items-center justify-between gap-4 p-4 md:flex-col md:items-stretch md:gap-8 md:p-6">
        <p className="text-lg font-semibold">
          AuraStudio<span className="text-aura-lime">.Pro</span>
        </p>
        <nav aria-label="Main" className="flex gap-1 overflow-x-auto md:flex-col">
          {links.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                aria-current={active ? "page" : undefined}
                className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active ? "bg-aura-lime text-black" : "text-aura-muted hover:bg-white/5 hover:text-aura-ink"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
        <button
          type="button"
          onClick={signOut}
          className="rounded-lg border border-aura-line px-3 py-2 text-sm text-aura-muted transition-colors hover:text-aura-ink md:mt-auto"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
