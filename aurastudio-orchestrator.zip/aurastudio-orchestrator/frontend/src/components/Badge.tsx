import type { Lead } from "@/types";

const intentStyles: Record<string, string> = {
  high: "bg-aura-lime text-black",
  medium: "bg-yellow-500/20 text-yellow-300",
  low: "bg-white/10 text-aura-muted",
};

export function IntentBadge({ intent, score }: { intent: Lead["intent"]; score: number | null }) {
  if (!intent) {
    return <span className="text-xs text-aura-muted">Scoring...</span>;
  }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${intentStyles[intent]}`}>
      {intent}
      {score !== null ? <span className="opacity-70">{score}</span> : null}
    </span>
  );
}

const runStyles: Record<string, string> = {
  sent: "bg-aura-lime text-black",
  failed: "bg-red-500/20 text-red-300",
  skipped: "bg-white/10 text-aura-muted",
};

export function RunBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold ${runStyles[status] ?? runStyles.skipped}`}>
      {status}
    </span>
  );
}
