export default function StatCard({ label, value, hint }: { label: string; value: number | string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-aura-line bg-aura-surface p-5">
      <p className="text-sm text-aura-muted">{label}</p>
      <p className="mt-2 text-3xl font-semibold">{value}</p>
      {hint ? <p className="mt-1 text-xs text-aura-muted">{hint}</p> : null}
    </div>
  );
}
