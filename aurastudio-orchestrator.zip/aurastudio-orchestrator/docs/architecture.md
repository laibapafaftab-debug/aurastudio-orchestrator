# Architecture

```
Visitor ──► Website (static, GitHub Pages)
                │  POST /api/v1/leads  (CORS: only your site)
                ▼
          Caddy (HTTPS) ──► Backend (FastAPI) ──► Postgres / SQLite
                │                  │
                │                  ├─► Lead scoring (Claude, or rules fallback)
                │                  └─► n8n webhook (HMAC signed) ──► follow-up workflow
                ▼
          Dashboard (Next.js) ──proxies /api──► Backend
```

## Request flow for a new lead
1. The website form posts JSON to `/api/v1/leads`.
2. Backend checks rate limit, validates and cleans the input, drops honeypot hits, saves the lead and returns `202` immediately.
3. A background task scores the lead, saves the score, then sends the lead to n8n and logs the result in `workflow_runs`.
4. The admin sees the lead and the delivery log in the dashboard.

## Key decisions
- **Scoring and delivery run in the background** so the website form never waits on an AI call or on n8n.
- **Rules fallback** means a lead is always scored, even if the AI provider is down.
- **Dashboard proxies `/api`** so the browser talks to one origin and the session cookie stays first-party (no cross-site cookie settings).
- **Postgres-compatible SQLAlchemy** keeps SQLite for local work and Supabase/Postgres for production behind one setting.
- **Models:** `app/models/tables.py` are database tables, `app/models/schemas.py` are request and response shapes.

## Where to extend
- New automation steps: `app/services/` plus a call in `pipeline.py`.
- New dashboard page: a folder in `frontend/src/app/(app)/`, and a link in `components/Sidebar.tsx`.
- Schema changes: add Alembic migrations before the first production data exists.
