# Contributing

## Setup
See the README: Docker quick start, or the "Run without Docker" section.

## Workflow
1. Create a branch from `main`: `feature/<short-name>` or `fix/<short-name>`.
2. Keep changes small and focused. One pull request, one purpose.
3. Add or update tests. Backend: `cd backend && pytest -q`. Dashboard: `cd frontend && npm run build`.
4. Open a pull request using the template. CI must be green before merging.

## Commit messages
Short, present tense, say what and why: `Add rate limit to login`, `Fix lead status filter`.

## Code layout rules
- **Backend:** routes in `app/api`, business logic in `app/services`, settings/security in `app/core`, tables and schemas in `app/models`. Routes stay thin.
- **Dashboard:** pages in `src/app`, reusable UI in `src/components`, API calls only through `src/lib/api.ts`.
- All user input is validated in `app/models/schemas.py`. Never build SQL by hand; use SQLAlchemy.
- Secrets only in `.env`. Anything new that needs configuration goes into `.env.example` with a comment.
